using System;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Room Business Logic Class
/// Handles all CRUD operations for the Rooms table.
/// Uses Database.cs as the data-access helper.
/// </summary>
public class RoomBL
{
    // ─────────────────────────────────────────────────────────────
    // READ operations
    // ─────────────────────────────────────────────────────────────

    /// <summary>Returns all rooms from the database.</summary>
    public static DataTable GetAllRooms()
    {
        string query = "SELECT RoomID, RoomNumber, RoomType, Price, Status FROM Rooms ORDER BY RoomNumber";
        return Database.GetDataTable(query);
    }

    /// <summary>Returns a single room by its primary key.</summary>
    public static DataTable GetRoomByID(int roomID)
    {
        string query = "SELECT RoomID, RoomNumber, RoomType, Price, Status FROM Rooms WHERE RoomID = @RoomID";
        SqlParameter[] parameters =
        {
            new SqlParameter("@RoomID", roomID)
        };
        return Database.GetDataTable(query, parameters);
    }

    /// <summary>
    /// Returns only rooms with Status = 'Available'.
    /// Used by the BookRoom page to populate the room dropdown.
    /// </summary>
    public static DataTable GetAvailableRooms()
    {
        string query = "SELECT RoomID, RoomNumber, RoomType, Price FROM Rooms WHERE Status = 'Available' ORDER BY RoomNumber";
        return Database.GetDataTable(query);
    }

    // ─────────────────────────────────────────────────────────────
    // CREATE
    // ─────────────────────────────────────────────────────────────

    /// <summary>
    /// Inserts a new room. Status defaults to 'Available'.
    /// Returns 1 if successful, 0 otherwise.
    /// </summary>
    public static int AddRoom(string roomNumber, string roomType, decimal price)
    {
        string query = @"INSERT INTO Rooms (RoomNumber, RoomType, Price, Status)
                         VALUES (@RoomNumber, @RoomType, @Price, 'Available')";

        SqlParameter[] parameters =
        {
            new SqlParameter("@RoomNumber", roomNumber.Trim()),
            new SqlParameter("@RoomType",   roomType.Trim()),
            new SqlParameter("@Price",      price)
        };

        return Database.ExecuteNonQuery(query, parameters);
    }

    // ─────────────────────────────────────────────────────────────
    // UPDATE
    // ─────────────────────────────────────────────────────────────

    /// <summary>Updates an existing room's details.</summary>
    public static int UpdateRoom(int roomID, string roomNumber, string roomType, decimal price, string status)
    {
        string query = @"UPDATE Rooms
                         SET RoomNumber = @RoomNumber,
                             RoomType   = @RoomType,
                             Price      = @Price,
                             Status     = @Status
                         WHERE RoomID = @RoomID";

        SqlParameter[] parameters =
        {
            new SqlParameter("@RoomID",     roomID),
            new SqlParameter("@RoomNumber", roomNumber.Trim()),
            new SqlParameter("@RoomType",   roomType.Trim()),
            new SqlParameter("@Price",      price),
            new SqlParameter("@Status",     status)
        };

        return Database.ExecuteNonQuery(query, parameters);
    }

    /// <summary>
    /// Updates only the Status column of a room.
    /// Called by BookingBL when booking / cancelling a booking.
    /// </summary>
    public static int UpdateRoomStatus(int roomID, string status)
    {
        string query = "UPDATE Rooms SET Status = @Status WHERE RoomID = @RoomID";

        SqlParameter[] parameters =
        {
            new SqlParameter("@RoomID", roomID),
            new SqlParameter("@Status", status)
        };

        return Database.ExecuteNonQuery(query, parameters);
    }

    // ─────────────────────────────────────────────────────────────
    // DELETE
    // ─────────────────────────────────────────────────────────────

    /// <summary>
    /// Deletes a room only if it has no confirmed bookings.
    /// Returns 1 if deleted, 0 if not found or has active bookings.
    /// </summary>
    public static int DeleteRoom(int roomID)
    {
        // Safety check: do not delete a currently booked room
        string checkQuery = @"SELECT COUNT(*) FROM Bookings
                               WHERE RoomID = @RoomID AND Status = 'Confirmed'";

        SqlParameter[] checkParams = { new SqlParameter("@RoomID", roomID) };

        int activeBookings = Convert.ToInt32(Database.ExecuteScalar(checkQuery, checkParams));

        if (activeBookings > 0)
            return -1; // Signal: cannot delete (has active bookings)

        string deleteQuery = "DELETE FROM Rooms WHERE RoomID = @RoomID";
        SqlParameter[] deleteParams = { new SqlParameter("@RoomID", roomID) };

        return Database.ExecuteNonQuery(deleteQuery, deleteParams);
    }

    // ─────────────────────────────────────────────────────────────
    // DASHBOARD STATS
    // ─────────────────────────────────────────────────────────────

    /// <summary>Returns the total number of rooms.</summary>
    public static int GetTotalRooms()
    {
        object result = Database.ExecuteScalar("SELECT COUNT(*) FROM Rooms");
        return result != null ? Convert.ToInt32(result) : 0;
    }

    /// <summary>Returns the number of available rooms.</summary>
    public static int GetAvailableRoomsCount()
    {
        object result = Database.ExecuteScalar("SELECT COUNT(*) FROM Rooms WHERE Status = 'Available'");
        return result != null ? Convert.ToInt32(result) : 0;
    }

    /// <summary>Returns the number of booked rooms.</summary>
    public static int GetBookedRoomsCount()
    {
        object result = Database.ExecuteScalar("SELECT COUNT(*) FROM Rooms WHERE Status = 'Booked'");
        return result != null ? Convert.ToInt32(result) : 0;
    }
}
