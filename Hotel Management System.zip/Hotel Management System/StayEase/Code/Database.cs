using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Database Helper Class (ADO.NET)
/// Provides reusable methods for all database operations.
/// All pages use this class to talk to SQL Server.
/// </summary>
public class Database
{
    // Read the connection string from Web.config → <connectionStrings>
    private static readonly string connectionString =
        ConfigurationManager.ConnectionStrings["StayEaseDB"].ConnectionString;

    // ─────────────────────────────────────────────────────────────
    // GetConnection()  – Returns an open-ready SqlConnection object
    // ─────────────────────────────────────────────────────────────
    /// <summary>Returns a new SqlConnection (not yet opened).</summary>
    public static SqlConnection GetConnection()
    {
        return new SqlConnection(connectionString);
    }

    // ─────────────────────────────────────────────────────────────
    // GetDataTable()  – SELECT queries → DataTable
    // ─────────────────────────────────────────────────────────────
    /// <summary>
    /// Executes a SELECT query and returns the results as a DataTable.
    /// Automatically uses using blocks to dispose connection and command.
    /// </summary>
    /// <param name="query">SQL SELECT statement</param>
    /// <param name="parameters">Optional SqlParameter array for parameterised queries</param>
    /// <returns>DataTable filled with query results</returns>
    public static DataTable GetDataTable(string query, SqlParameter[] parameters = null)
    {
        DataTable dt = new DataTable();

        try
        {
            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                // Add parameters to prevent SQL injection
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);

                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    conn.Open();
                    da.Fill(dt);
                }
            }
        }
        catch (SqlException ex)
        {
            // Log the error and rethrow so pages can display a message
            System.Diagnostics.Debug.WriteLine("DB Error (GetDataTable): " + ex.Message);
            throw;
        }

        return dt;
    }

    // ─────────────────────────────────────────────────────────────
    // ExecuteNonQuery()  – INSERT / UPDATE / DELETE
    // ─────────────────────────────────────────────────────────────
    /// <summary>
    /// Executes an INSERT, UPDATE, or DELETE command.
    /// </summary>
    /// <param name="query">SQL DML statement</param>
    /// <param name="parameters">Optional SqlParameter array</param>
    /// <returns>Number of rows affected</returns>
    public static int ExecuteNonQuery(string query, SqlParameter[] parameters = null)
    {
        int rowsAffected = 0;

        try
        {
            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);

                conn.Open();
                rowsAffected = cmd.ExecuteNonQuery();
            }
        }
        catch (SqlException ex)
        {
            System.Diagnostics.Debug.WriteLine("DB Error (ExecuteNonQuery): " + ex.Message);
            throw;
        }

        return rowsAffected;
    }

    // ─────────────────────────────────────────────────────────────
    // ExecuteScalar()  – Returns a single value (e.g. COUNT, SUM)
    // ─────────────────────────────────────────────────────────────
    /// <summary>
    /// Executes a query and returns the first column of the first row.
    /// Useful for COUNT(*), MAX, SUM etc.
    /// </summary>
    /// <param name="query">SQL query returning a single value</param>
    /// <param name="parameters">Optional SqlParameter array</param>
    /// <returns>A boxed object — cast it to the expected type</returns>
    public static object ExecuteScalar(string query, SqlParameter[] parameters = null)
    {
        object result = null;

        try
        {
            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);

                conn.Open();
                result = cmd.ExecuteScalar();
            }
        }
        catch (SqlException ex)
        {
            System.Diagnostics.Debug.WriteLine("DB Error (ExecuteScalar): " + ex.Message);
            throw;
        }

        return result;
    }
}
