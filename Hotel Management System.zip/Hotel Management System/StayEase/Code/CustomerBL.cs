using System;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Customer Business Logic Class
/// Handles all CRUD operations for the Customers table.
/// </summary>
public class CustomerBL
{
    // ─────────────────────────────────────────────────────────────
    // READ operations
    // ─────────────────────────────────────────────────────────────

    /// <summary>Returns all customers ordered by name.</summary>
    public static DataTable GetAllCustomers()
    {
        string query = @"SELECT CustomerID, CustomerName, Phone, Email, Address
                         FROM Customers
                         ORDER BY CustomerName";
        return Database.GetDataTable(query);
    }

    /// <summary>Returns a single customer by their primary key.</summary>
    public static DataTable GetCustomerByID(int customerID)
    {
        string query = @"SELECT CustomerID, CustomerName, Phone, Email, Address
                         FROM Customers
                         WHERE CustomerID = @CustomerID";

        SqlParameter[] parameters =
        {
            new SqlParameter("@CustomerID", customerID)
        };

        return Database.GetDataTable(query, parameters);
    }

    /// <summary>
    /// Returns all customers for use in dropdowns.
    /// Used by the BookRoom page.
    /// </summary>
    public static DataTable GetCustomersForDropdown()
    {
        string query = "SELECT CustomerID, CustomerName FROM Customers ORDER BY CustomerName";
        return Database.GetDataTable(query);
    }

    // ─────────────────────────────────────────────────────────────
    // CREATE
    // ─────────────────────────────────────────────────────────────

    /// <summary>Inserts a new customer record.</summary>
    public static int AddCustomer(string name, string phone, string email, string address)
    {
        string query = @"INSERT INTO Customers (CustomerName, Phone, Email, Address)
                         VALUES (@CustomerName, @Phone, @Email, @Address)";

        SqlParameter[] parameters =
        {
            new SqlParameter("@CustomerName", name.Trim()),
            new SqlParameter("@Phone",        phone.Trim()),
            new SqlParameter("@Email",        string.IsNullOrWhiteSpace(email)   ? (object)DBNull.Value : email.Trim()),
            new SqlParameter("@Address",      string.IsNullOrWhiteSpace(address) ? (object)DBNull.Value : address.Trim())
        };

        return Database.ExecuteNonQuery(query, parameters);
    }

    // ─────────────────────────────────────────────────────────────
    // UPDATE
    // ─────────────────────────────────────────────────────────────

    /// <summary>Updates an existing customer's details.</summary>
    public static int UpdateCustomer(int customerID, string name, string phone, string email, string address)
    {
        string query = @"UPDATE Customers
                         SET CustomerName = @CustomerName,
                             Phone        = @Phone,
                             Email        = @Email,
                             Address      = @Address
                         WHERE CustomerID = @CustomerID";

        SqlParameter[] parameters =
        {
            new SqlParameter("@CustomerID",   customerID),
            new SqlParameter("@CustomerName", name.Trim()),
            new SqlParameter("@Phone",        phone.Trim()),
            new SqlParameter("@Email",        string.IsNullOrWhiteSpace(email)   ? (object)DBNull.Value : email.Trim()),
            new SqlParameter("@Address",      string.IsNullOrWhiteSpace(address) ? (object)DBNull.Value : address.Trim())
        };

        return Database.ExecuteNonQuery(query, parameters);
    }

    // ─────────────────────────────────────────────────────────────
    // DELETE
    // ─────────────────────────────────────────────────────────────

    /// <summary>
    /// Deletes a customer only if they have no confirmed bookings.
    /// Returns -1 if the customer has active bookings.
    /// </summary>
    public static int DeleteCustomer(int customerID)
    {
        // Safety check: do not delete a customer with active bookings
        string checkQuery = @"SELECT COUNT(*) FROM Bookings
                               WHERE CustomerID = @CustomerID AND Status = 'Confirmed'";

        SqlParameter[] checkParams = { new SqlParameter("@CustomerID", customerID) };

        int activeBookings = Convert.ToInt32(Database.ExecuteScalar(checkQuery, checkParams));

        if (activeBookings > 0)
            return -1; // Cannot delete — has active bookings

        string deleteQuery = "DELETE FROM Customers WHERE CustomerID = @CustomerID";
        SqlParameter[] deleteParams = { new SqlParameter("@CustomerID", customerID) };

        return Database.ExecuteNonQuery(deleteQuery, deleteParams);
    }

    // ─────────────────────────────────────────────────────────────
    // STATS
    // ─────────────────────────────────────────────────────────────

    /// <summary>Returns the total number of customers.</summary>
    public static int GetTotalCustomers()
    {
        object result = Database.ExecuteScalar("SELECT COUNT(*) FROM Customers");
        return result != null ? Convert.ToInt32(result) : 0;
    }
}
