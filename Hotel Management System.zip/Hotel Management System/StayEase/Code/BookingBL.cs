using System;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Booking Business Logic Class
/// Handles all operations for the Bookings table.
/// Automatically updates Room status when a booking is created or cancelled.
/// </summary>
public class BookingBL
{
    // ─────────────────────────────────────────────────────────────
    // READ operations
    // ─────────────────────────────────────────────────────────────

    /// <summary>
    /// Returns all bookings joined with Customer and Room data.
    /// Ordered by most recent booking first.
    /// </summary>
    public static DataTable GetAllBookings()
    {
        string query = @"
            SELECT
                b.BookingID,
                c.CustomerName,
                r.RoomNumber,
                r.RoomType,
                b.CheckInDate,
                b.CheckOutDate,
                b.TotalAmount,
                b.Status,
                b.CustomerID,
                b.RoomID
            FROM Bookings b
            INNER JOIN Customers c ON b.CustomerID = c.CustomerID
            INNER JOIN Rooms     r ON b.RoomID     = r.RoomID
            ORDER BY b.BookingID DESC";

        return Database.GetDataTable(query);
    }

    /// <summary>Returns a single booking by its primary key.</summary>
    public static DataTable GetBookingByID(int bookingID)
    {
        string query = @"
            SELECT b.*, c.CustomerName, r.RoomNumber, r.RoomType
            FROM Bookings b
            INNER JOIN Customers c ON b.CustomerID = c.CustomerID
            INNER JOIN Rooms     r ON b.RoomID     = r.RoomID
            WHERE b.BookingID = @BookingID";

        SqlParameter[] parameters = { new SqlParameter("@BookingID", bookingID) };
        return Database.GetDataTable(query, parameters);
    }

    // ─────────────────────────────────────────────────────────────
    // CREATE — Book a Room
    // ─────────────────────────────────────────────────────────────

    /// <summary>
    /// Creates a new booking record and marks the room as 'Booked'.
    /// Uses two separate statements (booking insert + room status update).
    /// </summary>
    /// <returns>BookingID of the newly created booking, or -1 on failure.</returns>
    public static int BookRoom(int customerID, int roomID,
                               DateTime checkInDate, DateTime checkOutDate,
                               decimal totalAmount)
    {
        // Insert the booking and get the new BookingID
        string insertQuery = @"
            INSERT INTO Bookings (CustomerID, RoomID, CheckInDate, CheckOutDate, TotalAmount, Status)
            VALUES (@CustomerID, @RoomID, @CheckInDate, @CheckOutDate, @TotalAmount, 'Confirmed');
            SELECT SCOPE_IDENTITY();";  // Returns the new BookingID

        SqlParameter[] insertParams =
        {
            new SqlParameter("@CustomerID",   customerID),
            new SqlParameter("@RoomID",       roomID),
            new SqlParameter("@CheckInDate",  checkInDate),
            new SqlParameter("@CheckOutDate", checkOutDate),
            new SqlParameter("@TotalAmount",  totalAmount)
        };

        object scalarResult = Database.ExecuteScalar(insertQuery, insertParams);
        int newBookingID = scalarResult != null ? Convert.ToInt32(scalarResult) : -1;

        if (newBookingID > 0)
        {
            // Automatically mark the room as Booked
            RoomBL.UpdateRoomStatus(roomID, "Booked");
        }

        return newBookingID;
    }

    // ─────────────────────────────────────────────────────────────
    // CANCEL a Booking
    // ─────────────────────────────────────────────────────────────

    /// <summary>
    /// Sets booking status to 'Cancelled' and frees the room (Available).
    /// </summary>
    /// <returns>1 on success, 0 on failure.</returns>
    public static int CancelBooking(int bookingID, int roomID)
    {
        // Update booking status
        string updateQuery = @"UPDATE Bookings SET Status = 'Cancelled' WHERE BookingID = @BookingID";
        SqlParameter[] updateParams = { new SqlParameter("@BookingID", bookingID) };
        int rows = Database.ExecuteNonQuery(updateQuery, updateParams);

        if (rows > 0)
        {
            // Free the room again
            RoomBL.UpdateRoomStatus(roomID, "Available");
        }

        return rows;
    }

    // ─────────────────────────────────────────────────────────────
    // UTILITY — Amount Calculation
    // ─────────────────────────────────────────────────────────────

    /// <summary>
    /// Calculates the total booking amount:
    ///   TotalAmount = NumberOfNights × RoomPricePerNight
    /// </summary>
    public static decimal CalculateTotalAmount(int roomID, DateTime checkInDate, DateTime checkOutDate)
    {
        int nights = (checkOutDate - checkInDate).Days;
        if (nights <= 0) nights = 1;  // Minimum 1 night

        // Fetch price of the room
        string query = "SELECT Price FROM Rooms WHERE RoomID = @RoomID";
        SqlParameter[] parameters = { new SqlParameter("@RoomID", roomID) };

        object priceResult = Database.ExecuteScalar(query, parameters);
        decimal pricePerNight = priceResult != null ? Convert.ToDecimal(priceResult) : 0m;

        return nights * pricePerNight;
    }

    // ─────────────────────────────────────────────────────────────
    // STATS — Dashboard
    // ─────────────────────────────────────────────────────────────

    /// <summary>Returns the total number of confirmed bookings.</summary>
    public static int GetTotalConfirmedBookings()
    {
        object result = Database.ExecuteScalar("SELECT COUNT(*) FROM Bookings WHERE Status = 'Confirmed'");
        return result != null ? Convert.ToInt32(result) : 0;
    }
}
