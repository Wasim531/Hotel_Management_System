using System;
using System.Web.UI;

/// <summary>
/// Code-behind for Site.master (Master Page)
/// Handles session validation on every page load.
/// </summary>
public partial class Site : MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // ── Session Guard ──────────────────────────────────────
        // If the admin is not logged in, redirect to Login page.
        // This protects every page that uses this master page.
        if (Session["AdminLoggedIn"] == null || Session["AdminLoggedIn"].ToString() != "true")
        {
            Response.Redirect("~/Login.aspx");
        }
    }
}
