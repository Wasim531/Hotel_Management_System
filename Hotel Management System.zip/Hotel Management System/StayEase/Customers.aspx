<%@ Page Title="Customers" Language="C#" MasterPageFile="~/Site.master"
    AutoEventWireup="true" CodeFile="Customers.aspx.cs" Inherits="Customers" %>

<asp:Content ID="ContentHead" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="ContentBody" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h2><i class="fas fa-users"></i> Customer Management</h2>
            <p class="page-subtitle">View, edit, and delete customer records.</p>
        </div>
        <a href="AddCustomer.aspx" class="btn btn-primary">
            <i class="fas fa-user-plus me-1"></i> Add New Customer
        </a>
    </div>

    <!-- Alert Message -->
    <asp:Label ID="lblMessage" runat="server" Visible="false" CssClass="alert-custom" />

    <!-- Customers Card -->
    <div class="card">
        <div class="card-header">
            <span><i class="fas fa-list me-2"></i>All Customers</span>
            <!-- Search -->
            <div class="search-bar">
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                    <input type="text" id="customerSearch" class="form-control"
                        placeholder="Search customers..." onkeyup="filterTable()" />
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-wrapper">
                <asp:GridView ID="gvCustomers" runat="server"
                    CssClass="grid-table w-100"
                    AutoGenerateColumns="false"
                    DataKeyNames="CustomerID"
                    GridLines="None"
                    OnRowCommand="gvCustomers_RowCommand"
                    EmptyDataText="No customers found. Click 'Add New Customer' to get started."
                    EmptyDataRowStyle-CssClass="text-center text-muted p-4">
                    <Columns>
                        <asp:BoundField DataField="CustomerID"   HeaderText="#" ReadOnly="true" />
                        <asp:BoundField DataField="CustomerName" HeaderText="Name" />
                        <asp:BoundField DataField="Phone"        HeaderText="Phone" />
                        <asp:BoundField DataField="Email"        HeaderText="Email" />
                        <asp:BoundField DataField="Address"      HeaderText="Address" />
                        <asp:TemplateField HeaderText="Actions">
                            <ItemTemplate>
                                <a href='<%# "AddCustomer.aspx?id=" + Eval("CustomerID") %>'
                                    class="btn btn-sm btn-action-edit me-1" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <asp:LinkButton ID="btnDelete" runat="server"
                                    CommandName="DeleteCustomer"
                                    CommandArgument='<%# Eval("CustomerID") %>'
                                    CssClass="btn btn-sm btn-action-delete"
                                    OnClientClick="return confirm('Are you sure you want to delete this customer?');"
                                    title="Delete">
                                    <i class="fas fa-trash"></i>
                                </asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                </asp:GridView>
            </div>
        </div>
    </div>

</asp:Content>

<asp:Content ID="ContentScripts" ContentPlaceHolderID="scripts" runat="server">
<script>
    function filterTable() {
        var input  = document.getElementById('customerSearch');
        var filter = input.value.toLowerCase();
        var rows   = document.querySelectorAll('.grid-table tbody tr');
        rows.forEach(function(row) {
            row.style.display = row.innerText.toLowerCase().includes(filter) ? '' : 'none';
        });
    }
</script>
</asp:Content>
