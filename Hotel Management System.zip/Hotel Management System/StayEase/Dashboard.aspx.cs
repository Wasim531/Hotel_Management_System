using System;
using System.Data;
using System.Web.UI;

/// <summary>
/// Dashboard Page Code-Behind
/// Loads live statistics from the database and displays recent bookings.
/// </summary>
public partial class Dashboard : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadDashboardStats();
            LoadRecentBookings();
        }
    }

    /// <summary>
    /// Fetches room and customer counts and populates the stat card labels.
    /// </summary>
    private void LoadDashboardStats()
    {
        try
        {
            lblTotalRooms.Text      = RoomBL.GetTotalRooms().ToString();
            lblAvailableRooms.Text  = RoomBL.GetAvailableRoomsCount().ToString();
            lblBookedRooms.Text     = RoomBL.GetBookedRoomsCount().ToString();
            lblTotalCustomers.Text  = CustomerBL.GetTotalCustomers().ToString();
        }
        catch (Exception ex)
        {
            // Log silently — dashboard should still display
            System.Diagnostics.Debug.WriteLine("Dashboard stats error: " + ex.Message);
        }
    }

    /// <summary>
    /// Loads the 5 most recent bookings for the Recent Bookings GridView.
    /// </summary>
    private void LoadRecentBookings()
    {
        try
        {
            string query = @"
                SELECT TOP 5
                    c.CustomerName,
                    r.RoomNumber,
                    b.CheckInDate,
                    b.CheckOutDate,
                    b.Status
                FROM Bookings b
                INNER JOIN Customers c ON b.CustomerID = c.CustomerID
                INNER JOIN Rooms     r ON b.RoomID     = r.RoomID
                ORDER BY b.BookingID DESC";

            DataTable dt = Database.GetDataTable(query);
            gvRecentBookings.DataSource = dt;
            gvRecentBookings.DataBind();
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine("Recent bookings error: " + ex.Message);
        }
    }
}
