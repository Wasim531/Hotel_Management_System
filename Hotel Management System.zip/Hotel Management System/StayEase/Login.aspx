<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Login.aspx.cs" Inherits="Login" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="StayEase Hotel Management – Admin Login" />
    <title>StayEase – Admin Login</title>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
    <!-- Custom CSS -->
    <link href="CSS/site.css" rel="stylesheet" />
</head>
<body class="login-page">
    <form id="form1" runat="server">

        <div class="login-container">
            <div class="login-card">

                <!-- Card Header (Brand) -->
                <div class="login-header">
                    <i class="fas fa-hotel"></i>
                    <h1>StayEase</h1>
                    <p>Hotel Management System</p>
                </div>

                <!-- Card Body (Login Form) -->
                <div class="login-body">

                    <!-- Error / Success Message -->
                    <asp:Label ID="lblMessage" runat="server" Visible="false"
                        CssClass="alert alert-danger alert-custom d-flex align-items-center" role="alert">
                    </asp:Label>

                    <!-- Username -->
                    <div class="mb-4">
                        <label for="txtUsername" class="form-label">Username</label>
                        <div class="input-group">
                            <span class="input-group-text" id="usernameIcon">
                                <i class="fas fa-user"></i>
                            </span>
                            <asp:TextBox ID="txtUsername" runat="server"
                                CssClass="form-control"
                                placeholder="Enter your username"
                                aria-describedby="usernameIcon"
                                MaxLength="50" />
                        </div>
                        <asp:RequiredFieldValidator ID="rfvUsername" runat="server"
                            ControlToValidate="txtUsername"
                            ErrorMessage="&#9888; Username is required"
                            CssClass="text-danger small d-block mt-1"
                            Display="Dynamic" />
                    </div>

                    <!-- Password -->
                    <div class="mb-4">
                        <label for="txtPassword" class="form-label">Password</label>
                        <div class="input-group">
                            <span class="input-group-text" id="passwordIcon">
                                <i class="fas fa-lock"></i>
                            </span>
                            <asp:TextBox ID="txtPassword" runat="server"
                                TextMode="Password"
                                CssClass="form-control"
                                placeholder="Enter your password"
                                aria-describedby="passwordIcon"
                                MaxLength="100" />
                        </div>
                        <asp:RequiredFieldValidator ID="rfvPassword" runat="server"
                            ControlToValidate="txtPassword"
                            ErrorMessage="&#9888; Password is required"
                            CssClass="text-danger small d-block mt-1"
                            Display="Dynamic" />
                    </div>

                    <!-- Login Button -->
                    <div class="d-grid mt-2">
                        <asp:Button ID="btnLogin" runat="server"
                            Text="Login to Dashboard"
                            CssClass="btn btn-primary btn-lg fw-semibold"
                            OnClick="btnLogin_Click" />
                    </div>

                    <!-- Demo credentials hint -->
                    <p class="text-center mt-4 mb-0" style="font-size:0.8rem; color:#adb5bd;">
                        <i class="fas fa-info-circle me-1"></i>
                        Demo: <strong>admin</strong> / <strong>admin123</strong>
                    </p>
                </div>
            </div>

            <!-- Version / copyright -->
            <p class="text-center mt-3" style="color:rgba(255,255,255,0.5); font-size:0.75rem;">
                &copy; <%= DateTime.Now.Year %> StayEase &mdash; MCA Mini Project
            </p>
        </div>

    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-focus on username field
        document.addEventListener('DOMContentLoaded', function () {
            var username = document.getElementById('<%= txtUsername.ClientID %>');
            if (username) username.focus();
        });
    </script>
</body>
</html>
