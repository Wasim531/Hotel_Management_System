using System;
using System.Data;
using System.Web.UI;

/// <summary>
/// BookRoom Page Code-Behind
/// Handles room booking creation.
/// Loads available rooms and customers into dropdowns.
/// Automatically calculates the total amount and updates room status.
/// </summary>
public partial class BookRoom : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadCustomers();
            LoadAvailableRooms();
            // Set default dates
            txtCheckIn.Text  = DateTime.Today.ToString("yyyy-MM-dd");
            txtCheckOut.Text = DateTime.Today.AddDays(1).ToString("yyyy-MM-dd");
        }
    }

    /// <summary>Loads all customers into the customer dropdown.</summary>
    private void LoadCustomers()
    {
        try
        {
            DataTable dt = CustomerBL.GetCustomersForDropdown();
            ddlCustomer.Items.Clear();
            ddlCustomer.Items.Add(new System.Web.UI.WebControls.ListItem("-- Select Customer --", ""));

            foreach (DataRow row in dt.Rows)
            {
                ddlCustomer.Items.Add(new System.Web.UI.WebControls.ListItem(
                    row["CustomerName"].ToString(),
                    row["CustomerID"].ToString()
                ));
            }
        }
        catch (Exception ex)
        {
            ShowMessage("Error loading customers: " + ex.Message, "danger");
        }
    }

    /// <summary>Loads only available rooms into the room dropdown.</summary>
    private void LoadAvailableRooms()
    {
        try
        {
            DataTable dt = RoomBL.GetAvailableRooms();
            ddlRoom.Items.Clear();
            ddlRoom.Items.Add(new System.Web.UI.WebControls.ListItem("-- Select Room --", ""));

            foreach (DataRow row in dt.Rows)
            {
                string text = "Room " + row["RoomNumber"] + " - " + row["RoomType"] + " (Rs." + row["Price"] + "/night)";
                ddlRoom.Items.Add(new System.Web.UI.WebControls.ListItem(text, row["RoomID"].ToString()));
            }

            if (dt.Rows.Count == 0)
            {
                ShowMessage("No available rooms at the moment. Please check back later or cancel an existing booking.", "warning");
            }
        }
        catch (Exception ex)
        {
            ShowMessage("Error loading rooms: " + ex.Message, "danger");
        }
    }

    /// <summary>
    /// When a room is selected from the dropdown, display room info below.
    /// </summary>
    protected void ddlRoom_SelectedIndexChanged(object sender, EventArgs e)
    {
        int roomID;
        if (!string.IsNullOrEmpty(ddlRoom.SelectedValue) && int.TryParse(ddlRoom.SelectedValue, out roomID))
        {
            try
            {
                DataTable dt = RoomBL.GetRoomByID(roomID);
                if (dt.Rows.Count > 0)
                {
                    DataRow row = dt.Rows[0];
                    lblRoomInfo.Text   = "<strong>Room " + row["RoomNumber"] + "</strong> | " + row["RoomType"] + " | Rs." + Convert.ToDecimal(row["Price"]).ToString("N2") + " per night";
                    pnlRoomInfo.Visible = true;
                }
            }
            catch
            {
                pnlRoomInfo.Visible = false;
            }
        }
        else
        {
            pnlRoomInfo.Visible = false;
        }
    }

    /// <summary>
    /// Handles the Confirm Booking button click.
    /// Validates dates, calculates amount, creates booking, updates room status.
    /// </summary>
    protected void btnBook_Click(object sender, EventArgs e)
    {
        // ── Validate selections ──
        if (string.IsNullOrEmpty(ddlCustomer.SelectedValue) || string.IsNullOrEmpty(ddlRoom.SelectedValue))
        {
            ShowMessage("Please select both a customer and a room.", "danger");
            return;
        }

        int customerID = Convert.ToInt32(ddlCustomer.SelectedValue);
        int roomID     = Convert.ToInt32(ddlRoom.SelectedValue);

        // ── Validate dates ──
        DateTime checkIn, checkOut;
        if (!DateTime.TryParse(txtCheckIn.Text, out checkIn) ||
            !DateTime.TryParse(txtCheckOut.Text, out checkOut))
        {
            ShowMessage("Please enter valid check-in and check-out dates.", "danger");
            return;
        }

        if (checkOut <= checkIn)
        {
            ShowMessage("Check-out date must be after check-in date.", "danger");
            return;
        }

        if (checkIn < DateTime.Today)
        {
            ShowMessage("Check-in date cannot be in the past.", "danger");
            return;
        }

        try
        {
            // ── Calculate total amount ──
            decimal totalAmount = BookingBL.CalculateTotalAmount(roomID, checkIn, checkOut);
            txtTotalAmount.Text = totalAmount.ToString("N2");

            // ── Create the booking ──
            int newBookingID = BookingBL.BookRoom(customerID, roomID, checkIn, checkOut, totalAmount);

            if (newBookingID > 0)
            {
                // Redirect to bookings list with a success message
                Response.Redirect("~/Bookings.aspx?msg=booked&id=" + newBookingID);
            }
            else
            {
                ShowMessage("Failed to create booking. Please try again.", "danger");
            }
        }
        catch (Exception ex)
        {
            ShowMessage("Error creating booking: " + ex.Message, "danger");
        }
    }

    private void ShowMessage(string message, string type)
    {
        string icon = type == "success" ? "fa-check-circle"
                    : type == "warning" ? "fa-exclamation-triangle"
                    : "fa-times-circle";

        lblMessage.Text    = "<i class='fas " + icon + " me-2'></i>" + message;
        lblMessage.CssClass = "alert-custom alert alert-" + type;
        lblMessage.Visible  = true;
    }
}
