# StayEase – Hotel Management System
### MCA Mini Project | ASP.NET Web Forms + ADO.NET + SQL Server LocalDB

---

## 📁 Folder Structure

```
StayEase/
├── Code/
│   ├── Database.cs          ← ADO.NET helper (GetDataTable, ExecuteNonQuery, ExecuteScalar)
│   ├── RoomBL.cs            ← Room CRUD business logic
│   ├── CustomerBL.cs        ← Customer CRUD business logic
│   └── BookingBL.cs         ← Booking logic + auto room status update
├── App_Data/
│   └── StayEase.sql         ← Complete database creation script
├── CSS/
│   └── site.css             ← Custom styles (sidebar, cards, tables, forms)
├── Dashboard.aspx + .cs     ← Dashboard with live stat cards
├── Login.aspx + .cs         ← Admin login with session
├── Rooms.aspx + .cs         ← View all rooms (GridView)
├── AddRoom.aspx + .cs       ← Add / Edit room form
├── Customers.aspx + .cs     ← View all customers (GridView)
├── AddCustomer.aspx + .cs   ← Add / Edit customer form
├── BookRoom.aspx + .cs      ← New booking form
├── Bookings.aspx + .cs      ← View all bookings + Cancel
├── Logout.aspx + .cs        ← Clears session, redirects to Login
├── Site.master + .cs        ← Shared sidebar layout (used by all pages except Login/Logout)
├── Global.asax + .cs        ← Application events
└── Web.config               ← Connection string & app settings
```

---

## 🛠 Step-by-Step Setup in Visual Studio

### Step 1 – Create the Visual Studio Project

1. Open **Visual Studio 2019 / 2022**
2. Click **Create a new project**
3. Search for **"ASP.NET Web Application (.NET Framework)"** → Select it → Click **Next**
4. Set:
   - **Project name**: `StayEase`
   - **Location**: `d:\Hotel Management System\`
   - **Framework**: `.NET Framework 4.8`
5. Click **Create**
6. Choose **Empty** template, check **Web Forms** checkbox → Click **Create**

> 💡 Visual Studio creates a blank Web Forms project. We will now add our files.

---

### Step 2 – Copy the Generated Files

Copy all the files from `d:\Hotel Management System\StayEase\` into your newly created project folder, overwriting where prompted (especially `Web.config`).

**In Solution Explorer**, right-click the project → **Add → Existing Item** and add:
- All `.aspx` and `.aspx.cs` files
- `Site.master` and `Site.master.cs`
- `Global.asax` and `Global.asax.cs`
- `App_Code\*.cs` files
- `CSS\site.css`
- `App_Data\StayEase.sql`

---

### Step 3 – Set Up the Database

#### Option A – Using SQL Server Management Studio (SSMS)
1. Open SSMS and connect to `(localdb)\MSSQLLocalDB`
2. Open `App_Data\StayEase.sql`
3. Press **F5** to run the entire script
4. Verify: a new database **StayEaseDB** appears in Object Explorer

#### Option B – Using Visual Studio Server Explorer
1. In VS, go to **View → Server Explorer**
2. Right-click **Data Connections → Add Connection**
3. Server: `(localdb)\MSSQLLocalDB` → Click **OK**
4. Right-click the new connection → **New Query**
5. Paste the contents of `StayEase.sql` → Execute

---

### Step 4 – Verify the Connection String

Open `Web.config` and confirm this section:

```xml
<connectionStrings>
  <add name="StayEaseDB"
       connectionString="Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=StayEaseDB;Integrated Security=True;..."
       providerName="System.Data.SqlClient" />
</connectionStrings>
```

> ⚠️ If you use a named SQL Server instance (e.g., `SQLEXPRESS`), change `(localdb)\MSSQLLocalDB` to `.\SQLEXPRESS`.

---

### Step 5 – Set Login.aspx as the Start Page

1. In **Solution Explorer**, right-click `Login.aspx`
2. Click **Set As Start Page**

---

### Step 6 – Build & Run

1. Press **Ctrl + Shift + B** to build
2. Press **F5** to launch in your browser
3. Login with: **Username:** `admin` | **Password:** `admin123`

---

## 🗄 Database Tables

| Table | Key Columns |
|-------|-------------|
| `Admin` | AdminID, Username, Password |
| `Rooms` | RoomID, RoomNumber, RoomType, Price, Status |
| `Customers` | CustomerID, CustomerName, Phone, Email, Address |
| `Bookings` | BookingID, CustomerID (FK), RoomID (FK), CheckInDate, CheckOutDate, TotalAmount, Status |

---

## 🔄 Auto Room Status Logic

| Action | Room Status |
|--------|-------------|
| New booking created | ➡ **Booked** |
| Booking cancelled | ➡ **Available** |

This is handled automatically in `BookingBL.cs` — no manual update needed.

---

## 📄 Module Summary

| Module | Page | Operations |
|--------|------|------------|
| Login | `Login.aspx` | Authenticate admin, start session |
| Dashboard | `Dashboard.aspx` | View live counts (rooms, bookings, customers) |
| Rooms | `Rooms.aspx` + `AddRoom.aspx` | Add, Edit, Delete, View rooms |
| Customers | `Customers.aspx` + `AddCustomer.aspx` | Add, Edit, Delete, View customers |
| Bookings | `BookRoom.aspx` + `Bookings.aspx` | Book room, View bookings, Cancel booking |

---

## ⚙️ Technology Stack

| Layer | Technology |
|-------|-----------|
| UI | ASP.NET Web Forms (.NET 4.8), Bootstrap 5, Font Awesome 6 |
| Business Logic | C# (Code/*.cs) |
| Database Access | ADO.NET (SqlConnection, SqlCommand, SqlDataAdapter, SqlParameter) |
| Database | SQL Server LocalDB (StayEaseDB) |
| Validation | ASP.NET Validation Controls (RequiredFieldValidator, RegularExpressionValidator) |
| Authentication | Session-based (Session["AdminLoggedIn"]) |

---

## 🧪 Sample Test Data (already in SQL script)

| Type | Data |
|------|------|
| Admin | `admin` / `admin123` |
| Rooms | 8 rooms (101-402), all types |
| Customers | 5 sample customers |
| Bookings | 1 confirmed booking (Room 101) |

---

## ❓ Troubleshooting

| Problem | Solution |
|---------|----------|
| "Cannot open database StayEaseDB" | Run `StayEase.sql` first in SSMS |
| LocalDB not found | Install SQL Server Express LocalDB from Microsoft |
| Page shows blank | Ensure Session is set; check Master Page session guard |
| Room dropdown is empty | All rooms are booked — cancel a booking first |
| Unique constraint error on Room Number | That room number already exists — use a different one |
