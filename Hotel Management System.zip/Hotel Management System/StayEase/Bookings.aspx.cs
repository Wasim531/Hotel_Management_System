using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;

/// <summary>
/// Bookings Page Code-Behind
/// Loads all bookings and handles Cancel Booking action.
/// Cancelling a booking automatically sets the room back to 'Available'.
/// </summary>
public partial class Bookings : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // Check for redirect messages from BookRoom page
            string msg = Request.QueryString["msg"];
            if (msg == "booked")
            {
                string id = Request.QueryString["id"];
                ShowMessage("✔ Booking #" + id + " confirmed successfully! Room has been marked as Booked.", "success");
            }

            LoadBookings();
        }
    }

    /// <summary>Fetches all bookings (with joined Customer and Room data) and binds the GridView.</summary>
    private void LoadBookings()
    {
        try
        {
            DataTable dt = BookingBL.GetAllBookings();
            gvBookings.DataSource = dt;
            gvBookings.DataBind();
        }
        catch (Exception ex)
        {
            ShowMessage("Error loading bookings: " + ex.Message, "danger");
        }
    }

    /// <summary>
    /// Handles the Cancel Booking button click in the GridView.
    /// CommandArgument format: "BookingID|RoomID"
    /// </summary>
    protected void gvBookings_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "CancelBooking")
        {
            // Parse the composite argument: "BookingID|RoomID"
            string[] args      = e.CommandArgument.ToString().Split('|');
            int bookingID = Convert.ToInt32(args[0]);
            int roomID    = Convert.ToInt32(args[1]);

            try
            {
                int result = BookingBL.CancelBooking(bookingID, roomID);

                if (result > 0)
                    ShowMessage("✔ Booking #" + bookingID + " cancelled. Room is now available again.", "success");
                else
                    ShowMessage("Failed to cancel booking. Please try again.", "danger");
            }
            catch (Exception ex)
            {
                ShowMessage("Error cancelling booking: " + ex.Message, "danger");
            }

            LoadBookings(); // Refresh the GridView
        }
    }

    private void ShowMessage(string message, string type)
    {
        string icon = type == "success" ? "fa-check-circle"
                    : type == "warning" ? "fa-exclamation-triangle"
                    : "fa-times-circle";

        lblMessage.Text    = "<i class='fas " + icon + " me-2'></i>" + message;
        lblMessage.CssClass = "alert-custom alert alert-" + type;
        lblMessage.Visible  = true;
    }
}
