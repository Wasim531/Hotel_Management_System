<%@ Page Title="New Booking" Language="C#" MasterPageFile="~/Site.master"
    AutoEventWireup="true" CodeFile="BookRoom.aspx.cs" Inherits="BookRoom" %>

<asp:Content ID="ContentHead" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="ContentBody" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h2><i class="fas fa-calendar-plus"></i> New Booking</h2>
            <p class="page-subtitle">Book an available room for a customer.</p>
        </div>
        <a href="Bookings.aspx" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i> View All Bookings
        </a>
    </div>

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <span><i class="fas fa-calendar-check me-2"></i>Booking Details</span>
                </div>
                <div class="card-body">

                    <asp:Label ID="lblMessage" runat="server" Visible="false" CssClass="alert-custom" />

                    <!-- Customer -->
                    <div class="mb-4">
                        <label for="ddlCustomer" class="form-label">
                            Customer <span class="text-danger">*</span>
                        </label>
                        <asp:DropDownList ID="ddlCustomer" runat="server" CssClass="form-select">
                            <asp:ListItem Value="" Text="-- Select Customer --" />
                        </asp:DropDownList>
                        <asp:RequiredFieldValidator ID="rfvCustomer" runat="server"
                            ControlToValidate="ddlCustomer" InitialValue=""
                            ErrorMessage="&#9888; Please select a customer."
                            CssClass="text-danger small d-block mt-1" Display="Dynamic" />
                        <a href="AddCustomer.aspx" class="small text-primary mt-1 d-inline-block">
                            <i class="fas fa-plus-circle me-1"></i>Add new customer
                        </a>
                    </div>

                    <!-- Room -->
                    <div class="mb-4">
                        <label for="ddlRoom" class="form-label">
                            Available Room <span class="text-danger">*</span>
                        </label>
                        <asp:DropDownList ID="ddlRoom" runat="server" CssClass="form-select"
                            AutoPostBack="true" OnSelectedIndexChanged="ddlRoom_SelectedIndexChanged">
                            <asp:ListItem Value="" Text="-- Select Room --" />
                        </asp:DropDownList>
                        <asp:RequiredFieldValidator ID="rfvRoom" runat="server"
                            ControlToValidate="ddlRoom" InitialValue=""
                            ErrorMessage="&#9888; Please select a room."
                            CssClass="text-danger small d-block mt-1" Display="Dynamic" />
                        <!-- Room info badge shown after selection -->
                        <asp:Panel ID="pnlRoomInfo" runat="server" Visible="false">
                            <div class="mt-2 p-2 rounded" style="background:#e8f0fe; font-size:0.85rem;">
                                <i class="fas fa-info-circle me-1" style="color:#1a73e8;"></i>
                                <asp:Label ID="lblRoomInfo" runat="server" />
                            </div>
                        </asp:Panel>
                    </div>

                    <!-- Check-In / Check-Out Dates (side by side) -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <label for="txtCheckIn" class="form-label">
                                Check-In Date <span class="text-danger">*</span>
                            </label>
                            <asp:TextBox ID="txtCheckIn" runat="server"
                                CssClass="form-control"
                                TextMode="Date" />
                            <asp:RequiredFieldValidator ID="rfvCheckIn" runat="server"
                                ControlToValidate="txtCheckIn"
                                ErrorMessage="&#9888; Check-In date is required."
                                CssClass="text-danger small d-block mt-1" Display="Dynamic" />
                        </div>
                        <div class="col-md-6">
                            <label for="txtCheckOut" class="form-label">
                                Check-Out Date <span class="text-danger">*</span>
                            </label>
                            <asp:TextBox ID="txtCheckOut" runat="server"
                                CssClass="form-control"
                                TextMode="Date" />
                            <asp:RequiredFieldValidator ID="rfvCheckOut" runat="server"
                                ControlToValidate="txtCheckOut"
                                ErrorMessage="&#9888; Check-Out date is required."
                                CssClass="text-danger small d-block mt-1" Display="Dynamic" />
                        </div>
                    </div>

                    <!-- Total Amount (auto-calculated) -->
                    <div class="mb-4">
                        <label class="form-label">Total Amount (₹)</label>
                        <div class="input-group">
                            <span class="input-group-text">₹</span>
                            <asp:TextBox ID="txtTotalAmount" runat="server"
                                CssClass="form-control"
                                placeholder="Auto-calculated on booking"
                                ReadOnly="true"
                                style="background:#f8f9fa; font-weight:600; font-size:1rem;" />
                        </div>
                        <small class="text-muted">
                            <i class="fas fa-info-circle me-1"></i>
                            Amount = Number of Nights × Price per Night. Calculated at time of booking.
                        </small>
                    </div>

                    <!-- Buttons -->
                    <div class="d-flex gap-3 mt-2">
                        <asp:Button ID="btnBook" runat="server"
                            Text="Confirm Booking"
                            CssClass="btn btn-primary px-4 fw-semibold"
                            OnClick="btnBook_Click" />
                        <a href="Bookings.aspx" class="btn btn-outline-secondary px-4">Cancel</a>
                    </div>

                </div>
            </div>
        </div>
    </div>

</asp:Content>

<asp:Content ID="ContentScripts" ContentPlaceHolderID="scripts" runat="server">
<script>
    // Set minimum date for check-in to today, and check-out to tomorrow
    window.addEventListener('DOMContentLoaded', function () {
        var today    = new Date().toISOString().split('T')[0];
        var tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];

        var checkIn  = document.getElementById('<%= txtCheckIn.ClientID %>');
        var checkOut = document.getElementById('<%= txtCheckOut.ClientID %>');

        if (checkIn)  { checkIn.min  = today;    checkIn.value  = today; }
        if (checkOut) { checkOut.min = tomorrow;  checkOut.value = tomorrow; }

        // Enforce check-out > check-in on change
        if (checkIn) {
            checkIn.addEventListener('change', function () {
                var next = new Date(checkIn.value);
                next.setDate(next.getDate() + 1);
                checkOut.min = next.toISOString().split('T')[0];
                if (checkOut.value <= checkIn.value) {
                    checkOut.value = next.toISOString().split('T')[0];
                }
            });
        }
    });
</script>
</asp:Content>
