using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;

/// <summary>
/// Rooms Page Code-Behind
/// Loads and displays all rooms. Handles delete from GridView.
/// </summary>
public partial class Rooms : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadRooms();
        }
    }

    /// <summary>Fetches all rooms and binds them to the GridView.</summary>
    private void LoadRooms()
    {
        try
        {
            DataTable dt = RoomBL.GetAllRooms();
            gvRooms.DataSource = dt;
            gvRooms.DataBind();
        }
        catch (Exception ex)
        {
            ShowMessage("Error loading rooms: " + ex.Message, "danger");
        }
    }

    /// <summary>
    /// Handles GridView row commands (Edit redirects via anchor; Delete handled here).
    /// </summary>
    protected void gvRooms_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DeleteRoom")
        {
            int roomID = Convert.ToInt32(e.CommandArgument);

            try
            {
                int result = RoomBL.DeleteRoom(roomID);

                if (result == -1)
                {
                    ShowMessage("⚠ This room cannot be deleted because it has active bookings.", "warning");
                }
                else if (result > 0)
                {
                    ShowMessage("✔ Room deleted successfully.", "success");
                }
                else
                {
                    ShowMessage("Room not found.", "danger");
                }
            }
            catch (Exception ex)
            {
                ShowMessage("Error deleting room: " + ex.Message, "danger");
            }

            LoadRooms(); // Refresh the GridView
        }
    }

    /// <summary>Displays an alert message with the appropriate Bootstrap colour.</summary>
    private void ShowMessage(string message, string type)
    {
        // type: success | danger | warning | info
        string icon = type == "success" ? "fa-check-circle"
                    : type == "warning" ? "fa-exclamation-triangle"
                    : "fa-times-circle";

        lblMessage.Text    = "<i class='fas " + icon + " me-2'></i>" + message;
        lblMessage.CssClass = "alert-custom alert alert-" + type;
        lblMessage.Visible  = true;
    }
}
