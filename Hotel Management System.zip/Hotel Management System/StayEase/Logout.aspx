<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Logout.aspx.cs" Inherits="Logout" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="refresh" content="3;url=Login.aspx" />
    <title>Logging Out – StayEase</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
    <link href="CSS/site.css" rel="stylesheet" />
</head>
<body class="login-page">
    <form id="form1" runat="server">
        <div class="login-container" style="max-width:380px;">
            <div class="login-card">
                <div class="login-header">
                    <i class="fas fa-sign-out-alt"></i>
                    <h1>StayEase</h1>
                    <p>You have been logged out</p>
                </div>
                <div class="login-body text-center">
                    <div class="mb-3">
                        <div class="spinner-border text-primary" role="status" style="width:2.5rem;height:2.5rem;">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>
                    <p class="text-muted mb-4">Redirecting to login page in 3 seconds…</p>
                    <a href="Login.aspx" class="btn btn-primary w-100">
                        <i class="fas fa-arrow-left me-2"></i>Back to Login
                    </a>
                </div>
            </div>
        </div>
    </form>
</body>
</html>
