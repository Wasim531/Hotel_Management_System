using System.Reflection;
using System.Runtime.InteropServices;

// General Information about this assembly
[assembly: AssemblyTitle("StayEase")]
[assembly: AssemblyDescription("StayEase Hotel Management System - MCA Mini Project")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("StayEase")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.
[assembly: ComVisible(false)]

// Version information for this assembly
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
