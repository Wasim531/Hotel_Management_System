<%@ Page Title="Rooms" Language="C#" MasterPageFile="~/Site.master"
    AutoEventWireup="true" CodeFile="Rooms.aspx.cs" Inherits="Rooms" %>

<asp:Content ID="ContentHead" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="ContentBody" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h2><i class="fas fa-door-open"></i> Room Management</h2>
            <p class="page-subtitle">View, edit, and delete hotel rooms.</p>
        </div>
        <a href="AddRoom.aspx" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i> Add New Room
        </a>
    </div>

    <!-- Alert Message -->
    <asp:Label ID="lblMessage" runat="server" Visible="false" CssClass="alert-custom" />

    <!-- Rooms Card -->
    <div class="card">
        <div class="card-header">
            <span><i class="fas fa-list me-2"></i>All Rooms</span>
            <!-- Search Box -->
            <div class="search-bar">
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                    <input type="text" id="roomSearch" class="form-control"
                        placeholder="Search rooms..." onkeyup="filterTable()" />
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-wrapper">
                <asp:GridView ID="gvRooms" runat="server"
                    CssClass="grid-table w-100"
                    AutoGenerateColumns="false"
                    DataKeyNames="RoomID"
                    GridLines="None"
                    OnRowCommand="gvRooms_RowCommand"
                    EmptyDataText="No rooms found. Click 'Add New Room' to get started."
                    EmptyDataRowStyle-CssClass="text-center text-muted p-4">
                    <Columns>
                        <asp:BoundField DataField="RoomID"     HeaderText="#"           ReadOnly="true" />
                        <asp:BoundField DataField="RoomNumber" HeaderText="Room No." />
                        <asp:BoundField DataField="RoomType"   HeaderText="Type" />
                        <asp:BoundField DataField="Price"      HeaderText="Price (₹)"
                            DataFormatString="{0:N2}" HtmlEncode="false" />
                        <asp:TemplateField HeaderText="Status">
                            <ItemTemplate>
                                <span class='badge-status <%# Eval("Status").ToString() == "Available" ? "badge-available" : "badge-booked" %>'>
                                    <i class='fas <%# Eval("Status").ToString() == "Available" ? "fa-check-circle" : "fa-times-circle" %> me-1'></i>
                                    <%# Eval("Status") %>
                                </span>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Actions">
                            <ItemTemplate>
                                <a href='<%# "AddRoom.aspx?id=" + Eval("RoomID") %>'
                                    class="btn btn-sm btn-action-edit me-1" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <asp:LinkButton ID="btnDelete" runat="server"
                                    CommandName="DeleteRoom"
                                    CommandArgument='<%# Eval("RoomID") %>'
                                    CssClass="btn btn-sm btn-action-delete"
                                    OnClientClick="return confirm('Are you sure you want to delete this room?');"
                                    title="Delete">
                                    <i class="fas fa-trash"></i>
                                </asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                </asp:GridView>
            </div>
        </div>
    </div>

</asp:Content>

<asp:Content ID="ContentScripts" ContentPlaceHolderID="scripts" runat="server">
<script>
    // Live search / filter for the rooms table
    function filterTable() {
        var input  = document.getElementById('roomSearch');
        var filter = input.value.toLowerCase();
        var table  = document.querySelector('.grid-table');
        var rows   = table ? table.getElementsByTagName('tr') : [];

        for (var i = 1; i < rows.length; i++) {
            var text = rows[i].innerText.toLowerCase();
            rows[i].style.display = text.includes(filter) ? '' : 'none';
        }
    }
</script>
</asp:Content>
