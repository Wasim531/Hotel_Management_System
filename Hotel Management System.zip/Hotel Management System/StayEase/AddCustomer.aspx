<%@ Page Title="Add / Edit Customer" Language="C#" MasterPageFile="~/Site.master"
    AutoEventWireup="true" CodeFile="AddCustomer.aspx.cs" Inherits="AddCustomer" %>

<asp:Content ID="ContentHead" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="ContentBody" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h2><i class="fas fa-user-plus"></i>
                <asp:Label ID="lblPageTitle" runat="server" Text="Add New Customer" />
            </h2>
            <p class="page-subtitle">
                <asp:Label ID="lblPageSubtitle" runat="server" Text="Fill in the customer details below." />
            </p>
        </div>
        <a href="Customers.aspx" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i> Back to Customers
        </a>
    </div>

    <div class="row justify-content-center">
        <div class="col-lg-7">
            <div class="card">
                <div class="card-header">
                    <span><i class="fas fa-id-card me-2"></i>Customer Details</span>
                </div>
                <div class="card-body">

                    <asp:Label ID="lblMessage" runat="server" Visible="false" CssClass="alert-custom" />
                    <asp:HiddenField ID="hdnCustomerID" runat="server" Value="0" />

                    <!-- Customer Name -->
                    <div class="mb-4">
                        <label for="txtName" class="form-label">
                            Full Name <span class="text-danger">*</span>
                        </label>
                        <asp:TextBox ID="txtName" runat="server"
                            CssClass="form-control"
                            placeholder="e.g. Rahul Sharma"
                            MaxLength="100" />
                        <asp:RequiredFieldValidator ID="rfvName" runat="server"
                            ControlToValidate="txtName"
                            ErrorMessage="&#9888; Customer name is required."
                            CssClass="text-danger small d-block mt-1" Display="Dynamic" />
                    </div>

                    <!-- Phone -->
                    <div class="mb-4">
                        <label for="txtPhone" class="form-label">
                            Phone Number <span class="text-danger">*</span>
                        </label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-phone"></i></span>
                            <asp:TextBox ID="txtPhone" runat="server"
                                CssClass="form-control"
                                placeholder="e.g. 9876543210"
                                MaxLength="15" />
                        </div>
                        <asp:RequiredFieldValidator ID="rfvPhone" runat="server"
                            ControlToValidate="txtPhone"
                            ErrorMessage="&#9888; Phone number is required."
                            CssClass="text-danger small d-block mt-1" Display="Dynamic" />
                        <asp:RegularExpressionValidator ID="revPhone" runat="server"
                            ControlToValidate="txtPhone"
                            ValidationExpression="^[0-9]{10,15}$"
                            ErrorMessage="&#9888; Enter a valid 10–15 digit phone number."
                            CssClass="text-danger small d-block mt-1" Display="Dynamic" />
                    </div>

                    <!-- Email -->
                    <div class="mb-4">
                        <label for="txtEmail" class="form-label">Email Address</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                            <asp:TextBox ID="txtEmail" runat="server"
                                CssClass="form-control"
                                placeholder="e.g. rahul@email.com"
                                MaxLength="100" />
                        </div>
                        <asp:RegularExpressionValidator ID="revEmail" runat="server"
                            ControlToValidate="txtEmail"
                            ValidationExpression="^[\w\-\.]+@([\w\-]+\.)+[\w\-]{2,4}$"
                            ErrorMessage="&#9888; Enter a valid email address."
                            CssClass="text-danger small d-block mt-1" Display="Dynamic" />
                    </div>

                    <!-- Address -->
                    <div class="mb-4">
                        <label for="txtAddress" class="form-label">Address</label>
                        <asp:TextBox ID="txtAddress" runat="server"
                            TextMode="MultiLine" Rows="3"
                            CssClass="form-control"
                            placeholder="e.g. 12, MG Road, Mumbai, Maharashtra"
                            MaxLength="255" />
                    </div>

                    <!-- Buttons -->
                    <div class="d-flex gap-3">
                        <asp:Button ID="btnSave" runat="server"
                            Text="Save Customer"
                            CssClass="btn btn-primary px-4"
                            OnClick="btnSave_Click" />
                        <a href="Customers.aspx" class="btn btn-outline-secondary px-4">Cancel</a>
                    </div>

                </div>
            </div>
        </div>
    </div>

</asp:Content>
