<%@ Page Title="Add / Edit Room" Language="C#" MasterPageFile="~/Site.master"
    AutoEventWireup="true" CodeFile="AddRoom.aspx.cs" Inherits="AddRoom" %>

<asp:Content ID="ContentHead" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="ContentBody" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h2><i class="fas fa-door-open"></i>
                <asp:Label ID="lblPageTitle" runat="server" Text="Add New Room" />
            </h2>
            <p class="page-subtitle">
                <asp:Label ID="lblPageSubtitle" runat="server" Text="Fill in the details to add a new room." />
            </p>
        </div>
        <a href="Rooms.aspx" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i> Back to Rooms
        </a>
    </div>

    <!-- Form Card -->
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <div class="card">
                <div class="card-header">
                    <span><i class="fas fa-edit me-2"></i>Room Details</span>
                </div>
                <div class="card-body">

                    <!-- Alert Message -->
                    <asp:Label ID="lblMessage" runat="server" Visible="false" CssClass="alert-custom" />

                    <!-- Hidden field to hold RoomID for edit mode -->
                    <asp:HiddenField ID="hdnRoomID" runat="server" Value="0" />

                    <!-- Room Number -->
                    <div class="mb-4">
                        <label for="txtRoomNumber" class="form-label">
                            Room Number <span class="text-danger">*</span>
                        </label>
                        <asp:TextBox ID="txtRoomNumber" runat="server"
                            CssClass="form-control"
                            placeholder="e.g. 101, 202, 301"
                            MaxLength="10" />
                        <asp:RequiredFieldValidator ID="rfvRoomNumber" runat="server"
                            ControlToValidate="txtRoomNumber"
                            ErrorMessage="&#9888; Room number is required."
                            CssClass="text-danger small d-block mt-1" Display="Dynamic" />
                    </div>

                    <!-- Room Type -->
                    <div class="mb-4">
                        <label for="ddlRoomType" class="form-label">
                            Room Type <span class="text-danger">*</span>
                        </label>
                        <asp:DropDownList ID="ddlRoomType" runat="server" CssClass="form-select">
                            <asp:ListItem Value=""       Text="-- Select Room Type --" />
                            <asp:ListItem Value="Single" Text="Single" />
                            <asp:ListItem Value="Double" Text="Double" />
                            <asp:ListItem Value="Suite"  Text="Suite" />
                            <asp:ListItem Value="Deluxe" Text="Deluxe" />
                        </asp:DropDownList>
                        <asp:RequiredFieldValidator ID="rfvRoomType" runat="server"
                            ControlToValidate="ddlRoomType"
                            InitialValue=""
                            ErrorMessage="&#9888; Please select a room type."
                            CssClass="text-danger small d-block mt-1" Display="Dynamic" />
                    </div>

                    <!-- Price -->
                    <div class="mb-4">
                        <label for="txtPrice" class="form-label">
                            Price per Night (₹) <span class="text-danger">*</span>
                        </label>
                        <div class="input-group">
                            <span class="input-group-text">₹</span>
                            <asp:TextBox ID="txtPrice" runat="server"
                                CssClass="form-control"
                                placeholder="e.g. 2500.00"
                                MaxLength="10" />
                        </div>
                        <asp:RequiredFieldValidator ID="rfvPrice" runat="server"
                            ControlToValidate="txtPrice"
                            ErrorMessage="&#9888; Price is required."
                            CssClass="text-danger small d-block mt-1" Display="Dynamic" />
                        <asp:RegularExpressionValidator ID="revPrice" runat="server"
                            ControlToValidate="txtPrice"
                            ValidationExpression="^\d+(\.\d{1,2})?$"
                            ErrorMessage="&#9888; Enter a valid price (e.g. 1500 or 1500.50)."
                            CssClass="text-danger small d-block mt-1" Display="Dynamic" />
                    </div>

                    <!-- Status (visible only in edit mode) -->
                    <div class="mb-4" id="statusDiv" runat="server" visible="false">
                        <label for="ddlStatus" class="form-label">Status</label>
                        <asp:DropDownList ID="ddlStatus" runat="server" CssClass="form-select">
                            <asp:ListItem Value="Available" Text="Available" />
                            <asp:ListItem Value="Booked"    Text="Booked" />
                        </asp:DropDownList>
                    </div>

                    <!-- Action Buttons -->
                    <div class="d-flex gap-3 mt-2">
                        <asp:Button ID="btnSave" runat="server"
                            Text="Save Room"
                            CssClass="btn btn-primary px-4"
                            OnClick="btnSave_Click" />
                        <a href="Rooms.aspx" class="btn btn-outline-secondary px-4">Cancel</a>
                    </div>

                </div>
            </div>
        </div>
    </div>

</asp:Content>
