<%@ Page Title="Bookings" Language="C#" MasterPageFile="~/Site.master"
    AutoEventWireup="true" CodeFile="Bookings.aspx.cs" Inherits="Bookings" %>

<asp:Content ID="ContentHead" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="ContentBody" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h2><i class="fas fa-calendar-check"></i> Booking Management</h2>
            <p class="page-subtitle">View all bookings and cancel if needed.</p>
        </div>
        <a href="BookRoom.aspx" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i> New Booking
        </a>
    </div>

    <!-- Alert Message -->
    <asp:Label ID="lblMessage" runat="server" Visible="false" CssClass="alert-custom" />

    <!-- Bookings Card -->
    <div class="card">
        <div class="card-header">
            <span><i class="fas fa-list me-2"></i>All Bookings</span>
            <div class="search-bar">
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                    <input type="text" id="bookingSearch" class="form-control"
                        placeholder="Search bookings..." onkeyup="filterTable()" />
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-wrapper">
                <asp:GridView ID="gvBookings" runat="server"
                    CssClass="grid-table w-100"
                    AutoGenerateColumns="false"
                    DataKeyNames="BookingID"
                    GridLines="None"
                    OnRowCommand="gvBookings_RowCommand"
                    EmptyDataText="No bookings found."
                    EmptyDataRowStyle-CssClass="text-center text-muted p-4">
                    <Columns>
                        <asp:BoundField DataField="BookingID"    HeaderText="#" ReadOnly="true" />
                        <asp:BoundField DataField="CustomerName" HeaderText="Customer" />
                        <asp:TemplateField HeaderText="Room">
                            <ItemTemplate>
                                <span class="fw-semibold"><%# Eval("RoomNumber") %></span>
                                <br /><small class="text-muted"><%# Eval("RoomType") %></small>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:BoundField DataField="CheckInDate"  HeaderText="Check-In"
                            DataFormatString="{0:dd MMM yyyy}" HtmlEncode="false" />
                        <asp:BoundField DataField="CheckOutDate" HeaderText="Check-Out"
                            DataFormatString="{0:dd MMM yyyy}" HtmlEncode="false" />
                        <asp:BoundField DataField="TotalAmount"  HeaderText="Amount (₹)"
                            DataFormatString="{0:N2}" HtmlEncode="false" />
                        <asp:TemplateField HeaderText="Status">
                            <ItemTemplate>
                                <span class='badge-status <%# Eval("Status").ToString() == "Confirmed" ? "badge-confirmed" : "badge-cancelled" %>'>
                                    <i class='fas <%# Eval("Status").ToString() == "Confirmed" ? "fa-check-circle" : "fa-ban" %> me-1'></i>
                                    <%# Eval("Status") %>
                                </span>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Action">
                            <ItemTemplate>
                                <asp:LinkButton ID="btnCancel" runat="server"
                                    CommandName="CancelBooking"
                                    CommandArgument='<%# Eval("BookingID") + "|" + Eval("RoomID") %>'
                                    CssClass="btn btn-sm btn-action-cancel"
                                    Visible='<%# Eval("Status").ToString() == "Confirmed" %>'
                                    OnClientClick="return confirm('Are you sure you want to cancel this booking?');"
                                    title="Cancel Booking">
                                    <i class="fas fa-ban me-1"></i>Cancel
                                </asp:LinkButton>
                                <asp:Label ID="lblCancelled" runat="server"
                                    Visible='<%# Eval("Status").ToString() == "Cancelled" %>'
                                    Text="—" CssClass="text-muted" />
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                </asp:GridView>
            </div>
        </div>
    </div>

</asp:Content>

<asp:Content ID="ContentScripts" ContentPlaceHolderID="scripts" runat="server">
<script>
    function filterTable() {
        var input  = document.getElementById('bookingSearch');
        var filter = input.value.toLowerCase();
        var rows   = document.querySelectorAll('.grid-table tbody tr');
        rows.forEach(function(row) {
            row.style.display = row.innerText.toLowerCase().includes(filter) ? '' : 'none';
        });
    }
</script>
</asp:Content>
