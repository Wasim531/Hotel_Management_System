<%@ Page Title="Dashboard" Language="C#" MasterPageFile="~/Site.master"
    AutoEventWireup="true" CodeFile="Dashboard.aspx.cs" Inherits="Dashboard" %>

<asp:Content ID="ContentHead" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="ContentBody" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h2><i class="fas fa-chart-pie"></i> Dashboard</h2>
            <p class="page-subtitle">Welcome back, Admin! Here is a live overview of the hotel.</p>
        </div>
    </div>

    <!-- ═══════════════ STAT CARDS ═══════════════ -->
    <div class="row g-4 mb-4">

        <!-- Total Rooms -->
        <div class="col-sm-6 col-xl-3">
            <a href="Rooms.aspx" class="stat-card blue text-decoration-none d-flex">
                <div class="stat-icon blue">
                    <i class="fas fa-building"></i>
                </div>
                <div class="stat-info">
                    <h3><asp:Label ID="lblTotalRooms" runat="server" Text="0" /></h3>
                    <p>Total Rooms</p>
                </div>
            </a>
        </div>

        <!-- Available Rooms -->
        <div class="col-sm-6 col-xl-3">
            <a href="Rooms.aspx" class="stat-card green text-decoration-none d-flex">
                <div class="stat-icon green">
                    <i class="fas fa-door-open"></i>
                </div>
                <div class="stat-info">
                    <h3><asp:Label ID="lblAvailableRooms" runat="server" Text="0" /></h3>
                    <p>Available Rooms</p>
                </div>
            </a>
        </div>

        <!-- Booked Rooms -->
        <div class="col-sm-6 col-xl-3">
            <a href="Bookings.aspx" class="stat-card red text-decoration-none d-flex">
                <div class="stat-icon red">
                    <i class="fas fa-door-closed"></i>
                </div>
                <div class="stat-info">
                    <h3><asp:Label ID="lblBookedRooms" runat="server" Text="0" /></h3>
                    <p>Booked Rooms</p>
                </div>
            </a>
        </div>

        <!-- Total Customers -->
        <div class="col-sm-6 col-xl-3">
            <a href="Customers.aspx" class="stat-card orange text-decoration-none d-flex">
                <div class="stat-icon orange">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-info">
                    <h3><asp:Label ID="lblTotalCustomers" runat="server" Text="0" /></h3>
                    <p>Total Customers</p>
                </div>
            </a>
        </div>

    </div>

    <!-- ═══════════════ QUICK ACTIONS + RECENT BOOKINGS ═══════════════ -->
    <div class="row g-4">

        <!-- Quick Actions Card -->
        <div class="col-lg-4">
            <div class="card h-100">
                <div class="card-header">
                    <span><i class="fas fa-bolt me-2"></i>Quick Actions</span>
                </div>
                <div class="card-body d-flex flex-column gap-3">
                    <a href="AddRoom.aspx" class="btn btn-primary d-flex align-items-center gap-2">
                        <i class="fas fa-plus-square"></i> Add New Room
                    </a>
                    <a href="AddCustomer.aspx" class="btn btn-outline-primary d-flex align-items-center gap-2">
                        <i class="fas fa-user-plus"></i> Add New Customer
                    </a>
                    <a href="BookRoom.aspx" class="btn btn-outline-primary d-flex align-items-center gap-2">
                        <i class="fas fa-calendar-plus"></i> Create New Booking
                    </a>
                    <a href="Bookings.aspx" class="btn btn-outline-secondary d-flex align-items-center gap-2">
                        <i class="fas fa-list-alt"></i> View All Bookings
                    </a>
                </div>
            </div>
        </div>

        <!-- Recent Bookings Card -->
        <div class="col-lg-8">
            <div class="card h-100">
                <div class="card-header">
                    <span><i class="fas fa-clock me-2"></i>Recent Bookings</span>
                    <a href="Bookings.aspx" class="btn btn-sm btn-primary">View All</a>
                </div>
                <div class="card-body p-0">
                    <div class="table-wrapper">
                        <asp:GridView ID="gvRecentBookings" runat="server"
                            CssClass="grid-table w-100"
                            AutoGenerateColumns="false"
                            GridLines="None"
                            EmptyDataText="No bookings found."
                            EmptyDataRowStyle-CssClass="text-center text-muted p-4">
                            <Columns>
                                <asp:BoundField DataField="CustomerName" HeaderText="Customer" />
                                <asp:BoundField DataField="RoomNumber"   HeaderText="Room" />
                                <asp:BoundField DataField="CheckInDate"  HeaderText="Check-In"  DataFormatString="{0:dd MMM yyyy}" />
                                <asp:BoundField DataField="CheckOutDate" HeaderText="Check-Out" DataFormatString="{0:dd MMM yyyy}" />
                                <asp:TemplateField HeaderText="Status">
                                    <ItemTemplate>
                                        <span class='badge-status <%# Eval("Status").ToString() == "Confirmed" ? "badge-confirmed" : "badge-cancelled" %>'>
                                            <%# Eval("Status") %>
                                        </span>
                                    </ItemTemplate>
                                </asp:TemplateField>
                            </Columns>
                        </asp:GridView>
                    </div>
                </div>
            </div>
        </div>

    </div>

</asp:Content>
