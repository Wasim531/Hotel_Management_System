using System;
using System.Data;
using System.Web.UI;

/// <summary>
/// Add/Edit Room Page Code-Behind
/// Handles both Insert (new room) and Update (existing room) operations.
/// Reads the 'id' query string to determine add vs. edit mode.
/// </summary>
public partial class AddRoom : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // Check if an id was passed in the query string (edit mode)
            string idParam = Request.QueryString["id"];
            int roomID;
            if (!string.IsNullOrEmpty(idParam) && int.TryParse(idParam, out roomID) && roomID > 0)
            {
                // ── EDIT MODE ──
                hdnRoomID.Value = roomID.ToString();
                LoadRoomForEdit(roomID);
            }
            else
            {
                // ── ADD MODE ──
                hdnRoomID.Value = "0";
                lblPageTitle.Text    = "Add New Room";
                lblPageSubtitle.Text = "Fill in the details to add a new room.";
                statusDiv.Visible    = false;
                btnSave.Text         = "Save Room";
            }
        }
    }

    /// <summary>Loads existing room data into the form fields for editing.</summary>
    private void LoadRoomForEdit(int roomID)
    {
        try
        {
            DataTable dt = RoomBL.GetRoomByID(roomID);

            if (dt.Rows.Count > 0)
            {
                DataRow row = dt.Rows[0];

                txtRoomNumber.Text         = row["RoomNumber"].ToString();
                ddlRoomType.SelectedValue  = row["RoomType"].ToString();
                txtPrice.Text              = row["Price"].ToString();
                ddlStatus.SelectedValue    = row["Status"].ToString();

                // Show status dropdown only in edit mode
                statusDiv.Visible    = true;
                lblPageTitle.Text    = "Edit Room";
                lblPageSubtitle.Text = "Update the details for Room " + row["RoomNumber"].ToString() + ".";
                btnSave.Text         = "Update Room";
            }
            else
            {
                ShowMessage("Room not found. Redirecting to rooms list...", "danger");
                Response.Redirect("~/Rooms.aspx");
            }
        }
        catch (Exception ex)
        {
            ShowMessage("Error loading room: " + ex.Message, "danger");
        }
    }

    /// <summary>
    /// Handles the Save / Update button click.
    /// Determines mode from the hidden RoomID field.
    /// </summary>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        // Collect form values
        string roomNumber = txtRoomNumber.Text.Trim();
        string roomType   = ddlRoomType.SelectedValue;
        string priceText  = txtPrice.Text.Trim();
        int    roomID     = Convert.ToInt32(hdnRoomID.Value);

        decimal price;
        if (!decimal.TryParse(priceText, out price) || price <= 0)
        {
            ShowMessage("Please enter a valid price greater than zero.", "danger");
            return;
        }

        try
        {
            if (roomID == 0)
            {
                // ── INSERT (Add Mode) ──
                int result = RoomBL.AddRoom(roomNumber, roomType, price);

                if (result > 0)
                {
                    Response.Redirect("~/Rooms.aspx?msg=added");
                }
                else
                {
                    ShowMessage("Failed to add room. Please try again.", "danger");
                }
            }
            else
            {
                // ── UPDATE (Edit Mode) ──
                string status = ddlStatus.SelectedValue;
                int result = RoomBL.UpdateRoom(roomID, roomNumber, roomType, price, status);

                if (result > 0)
                {
                    Response.Redirect("~/Rooms.aspx?msg=updated");
                }
                else
                {
                    ShowMessage("Failed to update room. Please try again.", "danger");
                }
            }
        }
        catch (Exception ex)
        {
            // Handle duplicate room number (unique constraint violation)
            if (ex.Message.Contains("UNIQUE") || ex.Message.Contains("duplicate"))
                ShowMessage("A room with this number already exists. Please use a different room number.", "warning");
            else
                ShowMessage("Error: " + ex.Message, "danger");
        }
    }

    private void ShowMessage(string message, string type)
    {
        string icon = type == "success" ? "fa-check-circle"
                    : type == "warning" ? "fa-exclamation-triangle"
                    : "fa-times-circle";

        lblMessage.Text    = "<i class='fas " + icon + " me-2'></i>" + message;
        lblMessage.CssClass = "alert-custom alert alert-" + type;
        lblMessage.Visible  = true;
    }
}
