using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

/// <summary>
/// Login Page Code-Behind
/// Validates admin credentials against the Admin table in the database.
/// </summary>
public partial class Login : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // If the admin is already logged in, go straight to Dashboard
        if (Session["AdminLoggedIn"] != null && Session["AdminLoggedIn"].ToString() == "true")
        {
            Response.Redirect("~/Dashboard.aspx");
        }
    }

    /// <summary>
    /// Handles the Login button click.
    /// Queries the Admin table and starts a session on success.
    /// </summary>
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        // ASP.NET Validation Controls will prevent reaching here if fields are empty
        string username = txtUsername.Text.Trim();
        string password = txtPassword.Text.Trim();

        try
        {
            // Parameterised query to prevent SQL injection
            string query = @"SELECT COUNT(*) FROM Admin
                             WHERE Username = @Username AND Password = @Password";

            SqlParameter[] parameters =
            {
                new SqlParameter("@Username", username),
                new SqlParameter("@Password", password)
            };

            object result = Database.ExecuteScalar(query, parameters);
            int count = result != null ? Convert.ToInt32(result) : 0;

            if (count > 0)
            {
                // ── Login successful ──
                Session["AdminLoggedIn"] = "true";
                Session["AdminUsername"] = username;

                // Redirect to Dashboard
                Response.Redirect("~/Dashboard.aspx");
            }
            else
            {
                // ── Invalid credentials ──
                ShowMessage("&#9888; Invalid username or password. Please try again.");
            }
        }
        catch (Exception ex)
        {
            ShowMessage("&#9888; An error occurred: " + ex.Message);
        }
    }

    /// <summary>Shows an error message below the form.</summary>
    private void ShowMessage(string message)
    {
        lblMessage.Text    = message;
        lblMessage.Visible = true;
    }
}
