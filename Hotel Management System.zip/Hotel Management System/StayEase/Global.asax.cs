using System;
using System.Web;
using System.Web.SessionState;

/// <summary>
/// Global Application Class - Handles application-level events.
/// </summary>
public partial class Global : HttpApplication
{
    /// <summary>Fires once when the application first starts.</summary>
    void Application_Start(object sender, EventArgs e)
    {
        // Application startup logic (if any)
    }

    /// <summary>Fires once when the application shuts down.</summary>
    void Application_End(object sender, EventArgs e)
    {
        // Cleanup logic (if any)
    }

    /// <summary>Fires whenever an unhandled exception occurs in the application.</summary>
    void Application_Error(object sender, EventArgs e)
    {
        Exception ex = Server.GetLastError();
        // Log the error (extend this for production logging)
        System.Diagnostics.Debug.WriteLine("Application Error: " + ex.Message);
    }

    /// <summary>Fires when a new session is started.</summary>
    void Session_Start(object sender, EventArgs e)
    {
        // Session initialization logic (if any)
    }

    /// <summary>Fires when a session expires or is abandoned.</summary>
    void Session_End(object sender, EventArgs e)
    {
        // Session cleanup logic (if any)
    }
}
