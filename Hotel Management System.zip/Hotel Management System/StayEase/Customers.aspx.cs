using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;

/// <summary>
/// Customers Page Code-Behind
/// Loads and displays all customers. Handles delete from GridView.
/// </summary>
public partial class Customers : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadCustomers();
        }
    }

    private void LoadCustomers()
    {
        try
        {
            DataTable dt = CustomerBL.GetAllCustomers();
            gvCustomers.DataSource = dt;
            gvCustomers.DataBind();
        }
        catch (Exception ex)
        {
            ShowMessage("Error loading customers: " + ex.Message, "danger");
        }
    }

    protected void gvCustomers_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DeleteCustomer")
        {
            int customerID = Convert.ToInt32(e.CommandArgument);

            try
            {
                int result = CustomerBL.DeleteCustomer(customerID);

                if (result == -1)
                    ShowMessage("⚠ This customer cannot be deleted because they have active bookings.", "warning");
                else if (result > 0)
                    ShowMessage("✔ Customer deleted successfully.", "success");
                else
                    ShowMessage("Customer not found.", "danger");
            }
            catch (Exception ex)
            {
                ShowMessage("Error deleting customer: " + ex.Message, "danger");
            }

            LoadCustomers();
        }
    }

    private void ShowMessage(string message, string type)
    {
        string icon = type == "success" ? "fa-check-circle"
                    : type == "warning" ? "fa-exclamation-triangle"
                    : "fa-times-circle";

        lblMessage.Text    = "<i class='fas " + icon + " me-2'></i>" + message;
        lblMessage.CssClass = "alert-custom alert alert-" + type;
        lblMessage.Visible  = true;
    }
}
