using System;
using System.Web.UI;

/// <summary>
/// Logout Page Code-Behind
/// Clears the session and redirects to Login.
/// </summary>
public partial class Logout : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Clear all session variables
        Session.Clear();
        Session.Abandon();

        // Clear authentication cookie if using Forms Authentication
        if (Request.Cookies[".ASPXAUTH"] != null)
        {
            var cookie = new System.Web.HttpCookie(".ASPXAUTH");
            cookie.Expires = DateTime.Now.AddDays(-1);
            Response.Cookies.Add(cookie);
        }

        // Redirect is handled by the meta refresh tag in Logout.aspx
        // Optionally redirect immediately:
        // Response.Redirect("~/Login.aspx");
    }
}
