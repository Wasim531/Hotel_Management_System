using System;
using System.Data;
using System.Web.UI;

/// <summary>
/// Add/Edit Customer Page Code-Behind
/// Handles both Insert and Update operations based on query string 'id'.
/// </summary>
public partial class AddCustomer : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string idParam = Request.QueryString["id"];
            int customerID;
            if (!string.IsNullOrEmpty(idParam) && int.TryParse(idParam, out customerID) && customerID > 0)
            {
                // ── EDIT MODE ──
                hdnCustomerID.Value = customerID.ToString();
                LoadCustomerForEdit(customerID);
            }
            else
            {
                // ── ADD MODE ──
                hdnCustomerID.Value  = "0";
                lblPageTitle.Text    = "Add New Customer";
                lblPageSubtitle.Text = "Fill in the customer details below.";
                btnSave.Text         = "Save Customer";
            }
        }
    }

    private void LoadCustomerForEdit(int customerID)
    {
        try
        {
            DataTable dt = CustomerBL.GetCustomerByID(customerID);

            if (dt.Rows.Count > 0)
            {
                DataRow row = dt.Rows[0];
                txtName.Text    = row["CustomerName"].ToString();
                txtPhone.Text   = row["Phone"].ToString();
                txtEmail.Text   = row["Email"].ToString();
                txtAddress.Text = row["Address"].ToString();

                lblPageTitle.Text    = "Edit Customer";
                lblPageSubtitle.Text = "Update details for " + row["CustomerName"].ToString() + ".";
                btnSave.Text         = "Update Customer";
            }
            else
            {
                Response.Redirect("~/Customers.aspx");
            }
        }
        catch (Exception ex)
        {
            ShowMessage("Error loading customer: " + ex.Message, "danger");
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        string name    = txtName.Text.Trim();
        string phone   = txtPhone.Text.Trim();
        string email   = txtEmail.Text.Trim();
        string address = txtAddress.Text.Trim();
        int customerID = Convert.ToInt32(hdnCustomerID.Value);

        try
        {
            if (customerID == 0)
            {
                // ── INSERT ──
                int result = CustomerBL.AddCustomer(name, phone, email, address);

                if (result > 0)
                    Response.Redirect("~/Customers.aspx?msg=added");
                else
                    ShowMessage("Failed to add customer. Please try again.", "danger");
            }
            else
            {
                // ── UPDATE ──
                int result = CustomerBL.UpdateCustomer(customerID, name, phone, email, address);

                if (result > 0)
                    Response.Redirect("~/Customers.aspx?msg=updated");
                else
                    ShowMessage("Failed to update customer. Please try again.", "danger");
            }
        }
        catch (Exception ex)
        {
            ShowMessage("Error: " + ex.Message, "danger");
        }
    }

    private void ShowMessage(string message, string type)
    {
        string icon = type == "success" ? "fa-check-circle"
                    : type == "warning" ? "fa-exclamation-triangle"
                    : "fa-times-circle";

        lblMessage.Text    = "<i class='fas " + icon + " me-2'></i>" + message;
        lblMessage.CssClass = "alert-custom alert alert-" + type;
        lblMessage.Visible  = true;
    }
}
