-- ============================================================
--  StayEase Hotel Management System - Database Script
--  Database  : StayEaseDB
--  Server    : (localdb)\MSSQLLocalDB
--  Run in    : SQL Server Management Studio or VS Server Explorer
-- ============================================================

USE master;
GO

-- Create the database if it does not exist
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'StayEaseDB')
BEGIN
    CREATE DATABASE StayEaseDB;
    PRINT 'Database StayEaseDB created successfully.';
END
ELSE
BEGIN
    PRINT 'Database StayEaseDB already exists.';
END
GO

USE StayEaseDB;
GO

-- ============================================================
-- TABLE: Admin
-- ============================================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Admin')
BEGIN
    CREATE TABLE Admin (
        AdminID   INT          PRIMARY KEY IDENTITY(1,1),
        Username  NVARCHAR(50) NOT NULL UNIQUE,
        Password  NVARCHAR(100) NOT NULL
    );
    PRINT 'Table Admin created.';
END
GO

-- ============================================================
-- TABLE: Rooms
-- ============================================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Rooms')
BEGIN
    CREATE TABLE Rooms (
        RoomID     INT           PRIMARY KEY IDENTITY(1,1),
        RoomNumber NVARCHAR(10)  NOT NULL UNIQUE,
        RoomType   NVARCHAR(50)  NOT NULL,          -- Single / Double / Suite / Deluxe
        Price      DECIMAL(10,2) NOT NULL,
        Status     NVARCHAR(20)  NOT NULL DEFAULT 'Available'  -- Available / Booked
    );
    PRINT 'Table Rooms created.';
END
GO

-- ============================================================
-- TABLE: Customers
-- ============================================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Customers')
BEGIN
    CREATE TABLE Customers (
        CustomerID   INT           PRIMARY KEY IDENTITY(1,1),
        CustomerName NVARCHAR(100) NOT NULL,
        Phone        NVARCHAR(15)  NOT NULL,
        Email        NVARCHAR(100) NULL,
        Address      NVARCHAR(255) NULL
    );
    PRINT 'Table Customers created.';
END
GO

-- ============================================================
-- TABLE: Bookings
-- ============================================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Bookings')
BEGIN
    CREATE TABLE Bookings (
        BookingID    INT           PRIMARY KEY IDENTITY(1,1),
        CustomerID   INT           NOT NULL REFERENCES Customers(CustomerID),
        RoomID       INT           NOT NULL REFERENCES Rooms(RoomID),
        CheckInDate  DATE          NOT NULL,
        CheckOutDate DATE          NOT NULL,
        TotalAmount  DECIMAL(10,2) NOT NULL,
        Status       NVARCHAR(20)  NOT NULL DEFAULT 'Confirmed'  -- Confirmed / Cancelled
    );
    PRINT 'Table Bookings created.';
END
GO

-- ============================================================
-- SAMPLE DATA
-- ============================================================

-- Admin credentials: admin / admin123
IF NOT EXISTS (SELECT * FROM Admin WHERE Username = 'admin')
BEGIN
    INSERT INTO Admin (Username, Password) VALUES ('admin', 'admin123');
    PRINT 'Admin user inserted.';
END
GO

-- Sample Rooms
IF NOT EXISTS (SELECT TOP 1 * FROM Rooms)
BEGIN
    INSERT INTO Rooms (RoomNumber, RoomType, Price, Status) VALUES
    ('101', 'Single',  1500.00, 'Available'),
    ('102', 'Single',  1500.00, 'Available'),
    ('201', 'Double',  2500.00, 'Available'),
    ('202', 'Double',  2500.00, 'Available'),
    ('301', 'Suite',   5000.00, 'Available'),
    ('302', 'Suite',   5000.00, 'Available'),
    ('401', 'Deluxe',  7500.00, 'Available'),
    ('402', 'Deluxe',  7500.00, 'Available');
    PRINT 'Sample rooms inserted.';
END
GO

-- Sample Customers
IF NOT EXISTS (SELECT TOP 1 * FROM Customers)
BEGIN
    INSERT INTO Customers (CustomerName, Phone, Email, Address) VALUES
    ('Rahul Sharma',  '9876543210', 'rahul@email.com',  'Mumbai, Maharashtra'),
    ('Priya Patel',   '8765432109', 'priya@email.com',  'Ahmedabad, Gujarat'),
    ('Amit Kumar',    '7654321098', 'amit@email.com',   'New Delhi, India'),
    ('Sneha Reddy',   '6543210987', 'sneha@email.com',  'Hyderabad, Telangana'),
    ('Vijay Mehta',   '5432109876', 'vijay@email.com',  'Jaipur, Rajasthan');
    PRINT 'Sample customers inserted.';
END
GO

-- Sample Booking (links Customer 1 to Room 101)
IF NOT EXISTS (SELECT TOP 1 * FROM Bookings)
BEGIN
    INSERT INTO Bookings (CustomerID, RoomID, CheckInDate, CheckOutDate, TotalAmount, Status)
    VALUES (1, 1, GETDATE(), DATEADD(DAY, 3, GETDATE()), 4500.00, 'Confirmed');

    -- Mark room 101 as Booked
    UPDATE Rooms SET Status = 'Booked' WHERE RoomID = 1;
    PRINT 'Sample booking inserted.';
END
GO

PRINT '============================';
PRINT 'StayEaseDB setup complete!';
PRINT '============================';
