@echo off
"C:\Program Files\Microsoft Visual Studio\18\Community\MSBuild\Current\Bin\MSBuild.exe" "D:\Hotel Management System\StayEase\StayEase.csproj" /nologo /v:minimal
echo BUILD EXIT CODE: %ERRORLEVEL%
